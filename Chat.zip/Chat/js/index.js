// 元素框选文字的时候
document.onselectstart = function(e) {
	e.preventDefault();
}
// 内容的切换及样式的改变
$('.chatList_option li').on('click', function() {
	var index = $(this).index()
	$(this).addClass('curreLi').siblings().removeClass('curreLi')
	$('.chatList_list ul').eq(index).addClass('curr').siblings().removeClass('curr')
})

//点击关闭按钮 执行关闭聊天列表 及登出
$('.close').on('click', function() {
	$('#chatList').addClass('cuurent')
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/logout.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId
		},
		success(data) {
			if (data.code == 0) {
				console.log(data)
				console.log('登出成功')
				setTimeout(function() {
					window.location.href = 'login.html'
				}, 2000)
			}
		}
	})
})

//拖动列表盒子实现换动位置
$('#chatList').on('mousedown', function(event) {
	if (event.target != this) {
		return
	} else {
		var offsetX = event.offsetX
		var offsetY = event.offsetY
		// event.preventDefault(); //DOM / IE11 

		document.onmousemove = function(event) {
			var moveX = event.pageX
			var moveY = event.pageY
			// event.preventDefault(); //DOM / IE11 
			var Left = moveX - offsetX
			var Top = moveY - offsetY
			if (offsetX > moveX) {
				Left = 0
			}
			if (offsetY > moveY) {
				Top = 0
			}
			$('#chatList').css({
				left: Left,
				top: Top
			})
		}
	}
})
$('#chatList').on('mouseup', function() {
	document.onmousemove = null
})

//获取所有用户接口
$.ajax({
	type: 'post',
	url: 'http://118.24.25.7/chat_api/interface/getOnlineUsers.php',
	data: {
		sign_str: sessionStorage.sign_str,
		user_id: sessionStorage.userId
	},
	success(data) {
		if (data.code == 0) {
			console.log(data)
			console.log('获取用户成功成功')
		}
	}
})

//获取自身数据

var userInfo = JSON.parse(sessionStorage.userInfo)
var nickname = userInfo.nickname
$(document).ready(function() {
	$('#nickname').html(nickname)
})


//1.申请好友  //2.申请框拖动  //3.点击弹出及关闭
//1.
var id = sessionStorage.getItem('userId')
$('#lookup').on('click', function() {
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/addFriend.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			friend_user_id: $('#friend_user_id').val()
		},
		success(data) {
			console.log(data)
			if (data.code == 0) {
				$('.add_show').html('申请成功!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
			} else {
				$('.add_show').html('申请失败!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
			}
			getInfo();
		},
		error(err) {
			console.log(err.statusText)
		}
	})
})
// 2.
$('#add').on('mousedown', function(event) {
	var offsetX = event.offsetX
	var offsetY = event.offsetY
	// event.preventDefault(); //DOM / IE11 

	document.onmousemove = function(event) {
		var moveX = event.pageX
		var moveY = event.pageY
		event.preventDefault(); //DOM / IE11 
		var Left = moveX - offsetX
		var Top = moveY - offsetY
		if (offsetX > moveX) {
			Left = 0
		}
		if (offsetY > moveY) {
			Top = 0
		}
		$('#add').css({
			left: Left,
			top: Top
		})
	}
})
$('#add').on('mouseup', function() {
	document.onmousemove = null
})
// 3.
$('#addfriend').on('click', function() {
	$('.add').addClass('curr_opacity')
})

$('.add_close').on('click', function() {
	$('.add').removeClass('curr_opacity')
})

//获取好友申请

function getInfo() {
	$.ajax({
		type: 'get',
		url: 'http://118.24.25.7/chat_api/interface/getFriendRequests.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
		},
		success(data) {
			if (data.code == 0) {
				sessionStorage.from_user_id = data.data[0].user_id;
				sessionStorage.request_id = data.data[0].request_id;
			}
		},
		error(err) {
			console.log(err.statusText)
		}
	})
}



//处理好友申请
$.ajax({
	type: 'POST',
	url: 'http://118.24.25.7/chat_api/interface/processFriendRequest.php',
	data: {
		sign_str: sessionStorage.sign_str,
		user_id: sessionStorage.userId,
		from_user_id: sessionStorage.from_user_id,
		request_id: sessionStorage.request_id,
		process_result: 1
	},
	success(data) {
		if (data.code == 0) {
			console.log(data)
			console.log('处理成功')
		}
	}
	// complete(){
	// 	setTimeout(getInfo,1000)
	// }
})


//1. 获取好友列表 2.列表手风琴样式
// 1.
$.ajax({
	type: 'GET',
	url: 'http://118.24.25.7/chat_api/interface/getFriends.php',
	data: {
		sign_str: sessionStorage.sign_str,
		user_id: sessionStorage.userId,
	},
	success(data) {
		console.log(data)
		var str = '';
		data.data.forEach(function(item, index) {
			str +=
				`
			<div>
			    <span class="friend_img"></span>
				<span class="friendName">${item.nickname}</span>
				<span class="friendName">${item.user_id}</span>
			</div>
			`
		})
		$('.contactsList li').eq(0).html(`<p id="list" onclick="show()">>前端23班4组</p>` + str)

	},
	error(err) {
		console.log(err.statusText)
	}
	// complete(){
	// 	setTimeout(getInfo,1000)
	// }
})
//2.
function show() {
	var targetParent = $('#list').parent();
	var divs = targetParent.children('div');
	var aDivLen = divs.length;
	if (targetParent.height() == 0 || targetParent.height() == 35) {
		targetParent.css({
			height: 35 + (divs.length) * 50 + 'px'
		}).siblings().height(35)
	} else {
		targetParent.css({
			height: 35
		})
	}
}

// 删除好友

$('#delup').on('click', function() {
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/removeFriend.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			friend_id: $('#delfriend_user_id').val()
		},
		success(data) {
			if (data.code == 0) {
				$('.del_show').html('删除成功!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
			} else {
				$('.del_show').html('删除失败!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
			}
		},
		error(err) {
			console.log(err.statusText)
		}
	})
})

$('#delfriend').on('click', function() {
	$('.del').addClass('curr_del')
})
$('.del_close').on('click', function() {
	$('.del').removeClass("curr_del")
})


//1.聊天界面的拖动 2.聊天界面的显示及隐藏 3.聊天界面好友信息的获取
// 1.聊天界面的拖动 
$('.chatPanel').on('mousedown', function(event) {
	if (event.target != this) {
		return
	} else {
		var offsetX = event.offsetX
		var offsetY = event.offsetY
		// event.preventDefault(); //DOM / IE11

		document.onmousemove = function(event) {
			var moveX = event.pageX
			var moveY = event.pageY
			// event.preventDefault(); //DOM / IE11 
			var Left = moveX - offsetX
			var Top = moveY - offsetY
			if (offsetX > moveX) {
				Left = 0
			}
			if (offsetY > moveY) {
				Top = 0
			}
			$('.chatPanel').css({
				left: Left,
				top: Top
			})
		}
	}
})
$('.chatPanel').on('mouseup', function() {
	document.onmousemove = null
})

//2.聊天界面的显示及隐藏
$('#chatPanel_display').on('click', function() {
	$('.chatPanel').addClass('curr_chatPanel')
})
$('#chatPanel_show_close').on('click', function() {
	$('.chatPanel').removeClass('curr_chatPanel')
	$('.chatPanel_tab').html('')
})
$('.chatPanel_close').on('click', function() {
	$('.chatPanel').removeClass('curr_chatPanel')
	$('.chatPanel_tab').html('')
})

// 3.聊天界面好友信息的获取
//双击好友列表实现事件代理
// <span id="chatPanel_tab_nickname">${friend_id}</span>

var fId = null;
$('.contactsList li').on('dblclick', function(event) {
	if (event.target.nodeName == 'DIV') {
		console.log(event.target)	
		event.preventDefault();
		$('.chatPanel').addClass('curr_chatPanel')
		var nickname = event.target.children[1].innerText
		var id = event.target.children[2].innerText
		fId = id;
		console.log(nickname)
		// var friend_id=event.target.children[1].innerText
		$('#chatPanel_top_nickname').html(nickname)
		var str = '';
		// $('.curr_chatPanel_tab').siblings().removeClass('curr_chatPanel_tab')
		str +=
			`<li class='chatPanel_tab_li'>
		                <span class="friend_img"></span>
						<span id="chatPanel_tab_nickname">${nickname}</span>
						<span id="chatPanel_tab_nickname">${id}</span>
				   </li>
				`
		$('.chatPanel_tab').append(str)
	}else if(event.target.nodeName == 'SPAN'){
		var span_parent = $(event.target).parent()	 
		console.log(span_parent)
		$('.chatPanel').addClass('curr_chatPanel')
		
		var nickname = span_parent[0].children[1].innerText
		var id = span_parent[0].children[2].innerText
		fId = id;
		console.log(nickname)
		$('#chatPanel_top_nickname').html(nickname)
		var str = '';
		str +=
			`<li class='chatPanel_tab_li'>
		                <span class="friend_img"></span>
						<span id="chatPanel_tab_nickname">${nickname}</span>
						<span id="chatPanel_tab_nickname">${id}</span>
				   </li>
				`
		$('.chatPanel_tab').append(str)
	}

	// 获取好友历史消息记录
	$.ajax({
		type: 'get',
		url: 'http://118.24.25.7/chat_api/interface/getChatHistory.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			friend_id: id
		},
		success(data) {
			if (data.code == 0) {
				console.log('获取历史id为' + id + '的记录成功')
				console.log(data)
			}
			$('.chatPanel_content').html('')
			data.data.forEach(function(item, index) {
				if (item.user_id == id) {
					var str1 = ''
					str1 +=
						`<div class="chatPanel_content_receive">
								       <div>${nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
					             </div>
								`
					$('.chatPanel_content').append(str1)
				} else if (item.user_id != id) {
					var userInfo = JSON.parse(sessionStorage.userInfo);
					// console.log(userInfo)
					var str2 = ''
					str2 +=
						`<div class="chatPanel_content_user">
								    <div>${userInfo.nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
						 </div>
						`
					$('.chatPanel_content').append(str2)
				}
			})
	
			function setTop() {
				console.log($('.chatPanel_content')[0].scrollTop, $('.chatPanel_content')[0].scrollHeight)
				$('.chatPanel_content')[0].scrollTop = $('.chatPanel_content')[0].scrollHeight;
			}
			setTop();
		}
	})

})

// 单击好友tab列表选择要发送消息的好友及获取该好友的历史记录(事件代理)
$('.chatPanel_tab').on('click', function(event) {
	event.preventDefault();
	if (event.target.localName == 'li') {
		$(event.target).addClass('curr_chatPanel_tab').siblings().removeClass('curr_chatPanel_tab')
		event.preventDefault();
		var nickname = event.target.children[1].innerText
		var id = event.target.children[2].innerText
		fId = id
		console.log(id)
		// console.log(nickname)
		$('#chatPanel_top_nickname').html(nickname)
		// $('#.chatPanel_content').val('')
		$.ajax({
			type: 'get',
			url: 'http://118.24.25.7/chat_api/interface/getChatHistory.php',
			data: {
				sign_str: sessionStorage.sign_str,
				user_id: sessionStorage.userId,
				friend_id: fId
			},
			success(data) {
				if (data.code == 0) {
					console.log('获取历史id为' + id + '的记录成功')
					console.log(data)
				}
				$('.chatPanel_content').html('')
				data.data.forEach(function(item, index) {
					if (item.user_id == id) {
						var str1 = ''
						str1 +=
							`<div class="chatPanel_content_receive">
									       <div>${nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
						             </div>
									`
						$('.chatPanel_content').append(str1)
					} else if (item.user_id != id) {
						var userInfo = JSON.parse(sessionStorage.userInfo);
						// console.log(userInfo)
						var str2 = ''
						str2 +=
							`<div class="chatPanel_content_user">
									    <div>${userInfo.nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
									 </div>
									`
						$('.chatPanel_content').append(str2)
					}
				})

				function setTop() {
					console.log($('.chatPanel_content')[0].scrollTop, $('.chatPanel_content')[0].scrollHeight)
					$('.chatPanel_content')[0].scrollTop = $('.chatPanel_content')[0].scrollHeight;
				}
				setTop();
			}
		})
	}else if(event.target.localName == 'span'){
		var span_parent2 = $(event.target).parent()
		span_parent2.addClass('curr_chatPanel_tab').siblings().removeClass('curr_chatPanel_tab')
		var nickname =span_parent2[0].children[1].innerText
		var id = span_parent2[0].children[2].innerText
		fId = id
		console.log(id)
		// console.log(nickname)
		$('#chatPanel_top_nickname').html(nickname)
		// $('#.chatPanel_content').val('')
		$.ajax({
			type: 'get',
			url: 'http://118.24.25.7/chat_api/interface/getChatHistory.php',
			data: {
				sign_str: sessionStorage.sign_str,
				user_id: sessionStorage.userId,
				friend_id: fId
			},
			success(data) {
				if (data.code == 0) {
					console.log('获取历史id为' + id + '的记录成功')
					console.log(data)
				}
				$('.chatPanel_content').html('')
				data.data.forEach(function(item, index) {
					if (item.user_id == id) {
						var str1 = ''
						str1 +=
							`<div class="chatPanel_content_receive">
									       <div>${nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
						             </div>
									`
						$('.chatPanel_content').append(str1)
					} else if (item.user_id != id) {
						var userInfo = JSON.parse(sessionStorage.userInfo);
						// console.log(userInfo)
						var str2 = ''
						str2 +=
							`<div class="chatPanel_content_user">
									    <div>${userInfo.nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
									 </div>
									`
						$('.chatPanel_content').append(str2)
					}
				})
		
				function setTop() {
					console.log($('.chatPanel_content')[0].scrollTop, $('.chatPanel_content')[0].scrollHeight)
					$('.chatPanel_content')[0].scrollTop = $('.chatPanel_content')[0].scrollHeight;
				}
				setTop();
			}
		})
	}
})


//单击发送按钮发送消息接口
$('#chatPanel_show_show').on('click', function() {
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/sendMessage.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			receive_user_id: fId,
			message: $('#chatContent').val()
		},
		success(data) {
			if (data.code == 0) {
				var userInfo = JSON.parse(sessionStorage.userInfo);
				// console.log(userInfo)
				var str2 = ''
				var chatContent = $('#chatContent').val()
				str2 =
					`<div class="chatPanel_content_user">
							    ${userInfo.nickname}<br/><div class="chatPanel_content_son">${chatContent}</div>
							 </div>
							`
				$('#chatContent').val('')
				$('.chatPanel_content').append(str2)
			}
		}
	})
})


//动态消息展示消息接口 及双击弹出聊天界面
// 1.动态消息展示消息
function getstr() {
	$.ajax({
		type: 'get',
		url: 'http://118.24.25.7/chat_api/interface/getMessages.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId
		},
		success(data) {
			if (data.code == 0) {
				// console.log(data.data[0].message)
				// console.log(data)
				var str = ''
				var str1 = ''
				data.data.forEach(function(item, index) {
					str = `<li><span class="friend_img"></span><span>${item.nickname}</span><span>${item.user_id}</span>:&nbsp;&nbsp;<span>${item.message}</span></li>`
					
					if ( item.nickname == $('#chatPanel_top_nickname').text() ){
						str1 =
							`<div class="chatPanel_content_receive">
								       <div>${item.nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
						       </div>
							`
						// console.log( $('#chatPanel_top_nickname').text())
					}
				})
				$('.newsList').append(str)
				$('.chatPanel_content').append(str1)
			}
		},
		error(err) {
			console.log(err.statusText)
		},
		complete() {
			setTimeout(getstr, 5000)
		}
	})
}
getstr();

//双击弹出聊天界面
$('.newsList').on('dblclick',function(event){
	if (event.target.nodeName == 'LI') {
		console.log(event.target)	
		event.preventDefault();
		$('.chatPanel').addClass('curr_chatPanel')
		var nickname = event.target.children[1].innerText
		var id = event.target.children[2].innerText
		fId = id;
		console.log(nickname)
		// var friend_id=event.target.children[1].innerText
		$('#chatPanel_top_nickname').html(nickname)
		var str = '';
		// $('.curr_chatPanel_tab').siblings().removeClass('curr_chatPanel_tab')
		str +=
			`<li class='chatPanel_tab_li'>
		                <span class="friend_img"></span>
						<span id="chatPanel_tab_nickname">${nickname}</span>
						<span id="chatPanel_tab_nickname">${id}</span>
				   </li>
				`
		$('.chatPanel_tab').append(str)
	}else if(event.target.nodeName == 'SPAN'){
		var span_parent = $(event.target).parent()	 
		console.log(span_parent)
		$('.chatPanel').addClass('curr_chatPanel')
		
		var nickname = span_parent[0].children[1].innerText
		var id = span_parent[0].children[2].innerText
		fId = id;
		console.log(nickname)
		$('#chatPanel_top_nickname').html(nickname)
		var str = '';
		str +=
			`<li class='chatPanel_tab_li'>
		                <span class="friend_img"></span>
						<span id="chatPanel_tab_nickname">${nickname}</span>
						<span id="chatPanel_tab_nickname">${id}</span>
				   </li>
				`
		$('.chatPanel_tab').append(str)
	}
	// 获取好友历史消息记录
	$.ajax({
		type: 'get',
		url: 'http://118.24.25.7/chat_api/interface/getChatHistory.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			friend_id: fId
		},
		success(data) {
			if (data.code == 0) {
				console.log('获取历史id为' + id + '的记录成功')
				console.log(data)
			}
			$('.chatPanel_content').html('')
			data.data.forEach(function(item, index) {
				if (item.user_id == id) {
					var str1 = ''
					str1 +=
						`<div class="chatPanel_content_receive">
								       <div>${nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
					             </div>
								`
					$('.chatPanel_content').append(str1)
				} else if (item.user_id != id) {
					var userInfo = JSON.parse(sessionStorage.userInfo);
					// console.log(userInfo)
					var str2 = ''
					str2 +=
						`<div class="chatPanel_content_user">
								    <div>${userInfo.nickname}</div><div class="chatPanel_content_son">${item.message}</div> 
						 </div>
						`
					$('.chatPanel_content').append(str2)
				}
			})
	
			function setTop() {
				console.log($('.chatPanel_content')[0].scrollTop, $('.chatPanel_content')[0].scrollHeight)
				$('.chatPanel_content')[0].scrollTop = $('.chatPanel_content')[0].scrollHeight;
			}
			setTop();
		}
	})
})


// 搜索用户 （回车事件）
$('#chatList_search').on('keydown', function(event) {
	if (event.keyCode == 13) {
		// $('.search').addClass('curr_search')
		$('.search').show(500)
		$.ajax({
			type: 'GET',
			url: 'http://118.24.25.7/chat_api/interface/getSearchUsers.php',
			data: {
				sign_str: sessionStorage.sign_str,
				user_id: sessionStorage.userId,
				search_text: $('#chatList_search').val()
			},
			success(data) {
				if (data.code == 0) {
					console.log(data)
					console.log('搜索用户成功')
					var str = '';
					data.data.forEach(function(item, index) {
						str +=
							` <li class="search_li">
						            <span class="search_li_img"><img src="img/search_li_img.jpg"></img></span>
									<span class="search_li_nickname">${item.nickname}</span>
									<span class="search_li_id">${item.id}</span>
									<div class="search_li_add" onclick="search_add(this)">
										添加
									</div>
								</li>
							`
					})
					$('.search_list').html(str)
				}
			}
		})
	}
})

//搜索结果弹框的关闭
$('.search_close').on('click', function(event) {
	$('.search').hide(100)
})
//搜索弹窗中点击添加，实现添加为好友
function search_add(obj) {
	// var search_li_id = $('.search_li').children().eq(2)[0].innerText
	var search_li_id = $(obj).parent().children().eq(2)[0].innerText
	search_li_id = parseInt(search_li_id)
	// console.log(search_li_id)
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/addFriend.php',
		data: {
			sign_str: sessionStorage.sign_str,
			user_id: sessionStorage.userId,
			friend_user_id: search_li_id
		},
		success(data) {
			console.log(data)
			if (data.code == 0) {
				$('.search_show').html('申请成功!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
				console.log('申请成功')
			} else {
				$('.search_show').html('申请失败!').css({
					bottom: -30,
					transition: '.5s'
				}).show(1000).hide(1000)
				console.log('申请失败')
			}
		},
		error(err) {
			console.log(err.statusText)
		}
	})
}
